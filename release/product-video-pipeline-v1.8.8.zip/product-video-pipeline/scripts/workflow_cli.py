#!/usr/bin/env python3
"""Portable deterministic helpers for the product-video-pipeline skill.

This script never calls a paid model. It prepares batches, validates agent-created
content, records task IDs, and builds an offline human-review report.
"""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import html
import importlib.util
import json
import os
import re
import shutil
import sys
import threading
import uuid
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple
from urllib.parse import quote


IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp"}
FIXED_SEGMENTS = [(0, 4), (4, 11), (11, 15)]
WINDOWS_FORBIDDEN = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
TURNING_TERMS = (
    "转弯",
    "拐弯",
    "掉头",
    "原地转圈",
    "S形",
    "弧线",
    "绕行",
    "侧向移动",
    "倒车转向",
    "环绕",
)
FOLDING_PROCESS_TERMS = (
    "正在折叠",
    "正在展开",
    "折叠过程",
    "展开过程",
    "从展开到折叠",
    "从折叠到展开",
    "结构变化",
)
CTA_TERMS = ("可以看看", "可以了解", "可以考虑", "可以留意", "可以选择")
IMPROVEMENT_TERMS = (
    "方便",
    "轻松",
    "省心",
    "省力",
    "顺手",
    "愿意下楼",
    "不用总麻烦",
)
DELIVERABLE_NAMES = {
    "视频.mp4",
    "封面图.png",
    "发布正文.txt",
    "话题标签.txt",
    "标题.txt",
    "分镜图.png",
    "尾帧图.png",
}
WORK_DIR_NAME = "_工作文件"
WORK_CATEGORIES = ("任务状态", "生成过程", "验收记录", "历史版本")
TASK_STATE_PREFIXES = (
    "任务信息",
    "查询结果",
    "查询日志",
    "提交请求",
    "提交预览",
    "正式提交日志",
    "AutoDL",
    "dry-run日志",
)
REVIEW_PREFIXES = (
    "自动验收报告",
    "口播音轨验收",
    "人工验收",
    "人工处理说明",
    "候选经验",
    "验收对比",
    "验收预览图",
)
HISTORY_DIR_NAMES = {"失败版本", "视频版本"}
ITEM_DIR_PATTERN = re.compile(r"^V\d{3}_")
APPROVAL_LOG_NAME = "产出验收记录.json"
APPROVAL_DECISIONS = {"passed", "failed", "revoked"}
LEARNING_NODES = {
    "content",
    "storyboard",
    "cover",
    "audio",
    "video",
    "api",
    "polling",
    "download",
    "review",
}
_APPROVAL_THREAD_LOCKS: Dict[str, threading.Lock] = {}
_APPROVAL_THREAD_LOCKS_GUARD = threading.Lock()
_LEARNING_THREAD_LOCKS: Dict[str, threading.Lock] = {}
_LEARNING_THREAD_LOCKS_GUARD = threading.Lock()


def _load_policy_module():
    path = Path(__file__).with_name("pipeline_policy.py")
    spec = importlib.util.spec_from_file_location("product_video_pipeline_policy", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("无法加载 pipeline_policy.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _load_api_config_module():
    path = Path(__file__).with_name("api_config.py")
    spec = importlib.util.spec_from_file_location("product_video_api_config_runtime", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("无法加载 api_config.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _cli_image_provider(value: str) -> str:
    if value == "gpt_web":
        return "chatgpt_web"
    return _load_policy_module().normalize_image_provider(value)


class BatchItem:
    def __init__(self, video_id: str, selling_point: str, project_dir: Path):
        self.video_id = video_id
        self.selling_point = selling_point
        self.project_dir = project_dir


class BatchContext:
    def __init__(self, batch_dir: Path, product_images: Sequence[Path], items: Sequence[BatchItem]):
        self.batch_dir = batch_dir
        self.product_images = tuple(product_images)
        self.items = tuple(items)


def atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(text, encoding="utf-8")
    temporary.replace(path)


def atomic_write_json(path: Path, value: object) -> None:
    atomic_write_text(path, json.dumps(value, ensure_ascii=False, indent=2))


@contextlib.contextmanager
def _approval_log_lock(item_dir: Path):
    lock_path = approval_log_path(item_dir).with_suffix(".lock")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    key = str(lock_path.resolve()).casefold()
    with _APPROVAL_THREAD_LOCKS_GUARD:
        thread_lock = _APPROVAL_THREAD_LOCKS.setdefault(key, threading.Lock())
    with thread_lock:
        with lock_path.open("a+b") as stream:
            if stream.seek(0, os.SEEK_END) == 0:
                stream.write(b"0")
                stream.flush()
            stream.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(stream.fileno(), msvcrt.LK_LOCK, 1)
                try:
                    yield
                finally:
                    stream.seek(0)
                    msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(stream.fileno(), fcntl.LOCK_EX)
                try:
                    yield
                finally:
                    fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


@contextlib.contextmanager
def _learning_store_lock(knowledge_dir: Path):
    lock_path = knowledge_dir.resolve() / ".learning-rules.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    key = str(lock_path).casefold()
    with _LEARNING_THREAD_LOCKS_GUARD:
        thread_lock = _LEARNING_THREAD_LOCKS.setdefault(key, threading.Lock())
    with thread_lock:
        with lock_path.open("a+b") as stream:
            if stream.seek(0, os.SEEK_END) == 0:
                stream.write(b"0")
                stream.flush()
            stream.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(stream.fileno(), msvcrt.LK_LOCK, 1)
                try:
                    yield
                finally:
                    stream.seek(0)
                    msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(stream.fileno(), fcntl.LOCK_EX)
                try:
                    yield
                finally:
                    fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def read_json(path: Path, default: Optional[object] = None):
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def ensure_work_dirs(item_dir: Path) -> Dict[str, Path]:
    work_root = item_dir / WORK_DIR_NAME
    paths = {category: work_root / category for category in WORK_CATEGORIES}
    for path in paths.values():
        path.mkdir(parents=True, exist_ok=True)
    return paths


def work_path(item_dir: Path, category: str, filename: str) -> Path:
    if category not in WORK_CATEGORIES:
        raise ValueError(f"未知工作文件分类：{category}")
    return item_dir / WORK_DIR_NAME / category / filename


def read_compatible_path(item_dir: Path, category: str, filename: str) -> Path:
    preferred = work_path(item_dir, category, filename)
    return preferred if preferred.exists() else item_dir / filename


def approval_log_path(item_dir: Path) -> Path:
    return work_path(item_dir, "验收记录", APPROVAL_LOG_NAME)


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_approval_events(item_dir: Path) -> List[Dict[str, object]]:
    payload = read_json(approval_log_path(item_dir), {"events": []})
    if not isinstance(payload, dict) or not isinstance(payload.get("events"), list):
        raise ValueError("产出验收记录格式错误：必须包含 events 数组")
    if any(not isinstance(event, dict) for event in payload["events"]):
        raise ValueError("产出验收记录格式错误：events 只能包含对象")
    return list(payload["events"])


def latest_artifact_decision(
    events: Sequence[Dict[str, object]],
    artifact_name: str,
    sha256: str,
) -> Optional[Dict[str, object]]:
    return next(
        (
            event
            for event in reversed(events)
            if event.get("artifact_name") == artifact_name and event.get("sha256") == sha256
        ),
        None,
    )


def _snapshot_review_candidate(
    item_dir: Path,
    artifact_name: str,
    source_path: Path,
    digest: str,
    confirmed_at: datetime,
    event_id: str,
) -> Path:
    artifact = Path(artifact_name)
    snapshot_dir = work_path(item_dir, "历史版本", "验收候选") / artifact.stem
    snapshot_dir.mkdir(parents=True, exist_ok=True)
    timestamp = confirmed_at.strftime("%Y%m%dT%H%M%S%f%z")
    snapshot = snapshot_dir / f"{timestamp}_{digest[:12]}_{event_id}{artifact.suffix}"
    temporary = snapshot.with_suffix(snapshot.suffix + f".tmp.{uuid.uuid4().hex}")
    try:
        shutil.copyfile(source_path, temporary)
        if _sha256_file(temporary) != digest:
            raise OSError(f"验收候选快照哈希校验失败：{source_path}")
        temporary.replace(snapshot)
    finally:
        if temporary.exists():
            temporary.unlink()
    return snapshot


def record_artifact_decision(
    item_dir: Path,
    artifact_name: str,
    source_path: Path,
    decision: str,
    confirmed_by: str,
    feedback: str,
    now: Optional[datetime] = None,
) -> Dict[str, object]:
    item_dir = item_dir.resolve()
    if not item_dir.is_dir() or not ITEM_DIR_PATTERN.match(item_dir.name):
        raise ValueError(f"不是有效的单条任务目录：{item_dir}")
    if artifact_name not in DELIVERABLE_NAMES:
        raise ValueError(f"未知产出名称：{artifact_name}")
    if decision not in APPROVAL_DECISIONS:
        raise ValueError(f"验收决定只能是 passed、failed 或 revoked：{decision}")
    if not confirmed_by.strip():
        raise ValueError("确认人不能为空")
    if not feedback.strip():
        raise ValueError("验收反馈不能为空")

    source_path = source_path if source_path.is_absolute() else item_dir / source_path
    source_path = source_path.resolve()
    try:
        relative_source = source_path.relative_to(item_dir)
    except ValueError as exc:
        raise ValueError("候选文件必须位于单条任务目录内") from exc
    if not source_path.is_file():
        raise ValueError(f"候选文件不存在或不是普通文件：{source_path}")
    if source_path.parent == item_dir and source_path.name in DELIVERABLE_NAMES:
        raise ValueError("候选文件不能是一级固定产出，必须来自 _工作文件")

    confirmed_at = now or datetime.now().astimezone()
    if confirmed_at.utcoffset() is None:
        raise ValueError("确认时间必须包含时区")
    digest = _sha256_file(source_path)
    event_id = str(uuid.uuid4())
    snapshot = _snapshot_review_candidate(item_dir, artifact_name, source_path, digest, confirmed_at, event_id)
    event: Dict[str, object] = {
        "event_id": event_id,
        "artifact_name": artifact_name,
        "source_path": snapshot.relative_to(item_dir).as_posix(),
        "submitted_source_path": relative_source.as_posix(),
        "sha256": digest,
        "decision": decision,
        "confirmed_by": confirmed_by.strip(),
        "confirmed_at": confirmed_at.isoformat(),
        "feedback": feedback.strip(),
    }
    with _approval_log_lock(item_dir):
        events = load_approval_events(item_dir)
        events.append(event)
        atomic_write_json(approval_log_path(item_dir), {"events": events})
    return event


def _unique_artifact_archive_path(
    item_dir: Path,
    subdirectory: str,
    artifact_name: str,
    sha256: str,
    now: datetime,
) -> Path:
    archive_dir = work_path(item_dir, "历史版本", subdirectory)
    artifact = Path(artifact_name)
    timestamp = now.strftime("%Y%m%dT%H%M%S%z")
    base_name = f"{artifact.stem}_{timestamp}_{sha256[:8]}"
    candidate = archive_dir / f"{base_name}{artifact.suffix}"
    counter = 2
    while candidate.exists():
        candidate = archive_dir / f"{base_name}_{counter}{artifact.suffix}"
        counter += 1
    return candidate


def _archive_root_artifact(
    item_dir: Path,
    root_artifact: Path,
    subdirectory: str,
    now: datetime,
    *,
    dry_run: bool = False,
) -> Path:
    digest = _sha256_file(root_artifact)
    target = _unique_artifact_archive_path(item_dir, subdirectory, root_artifact.name, digest, now)
    if not dry_run:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(root_artifact), str(target))
    return target


def _publish_title_from_file(item_dir: Path) -> str:
    title_path = item_dir / "标题.txt"
    if not title_path.is_file():
        raise ValueError("缺少已验收的标题.txt，无法确定视频交付文件名")
    title_lines = [line.strip() for line in title_path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    publish_line = next(
        (line for line in title_lines if re.match(r"^\s*发布标题\s*[:：]", line)),
        title_lines[0] if title_lines else "",
    )
    raw_title = re.sub(r"^\s*(?:发布标题|标题)\s*[:：]\s*", "", publish_line).strip()
    cleaned = "".join(character if character.isalnum() else " " for character in raw_title)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    if not cleaned:
        raise ValueError("标题.txt 未包含可用于视频文件名的汉字、字母或数字")
    return cleaned


def deliverable_root_path(item_dir: Path, artifact_name: str) -> Path:
    if artifact_name not in DELIVERABLE_NAMES:
        raise ValueError(f"未知产出名称：{artifact_name}")
    if artifact_name == "视频.mp4":
        return item_dir / f"{_publish_title_from_file(item_dir)}.mp4"
    return item_dir / artifact_name


def promote_approved_artifact(item_dir: Path, event: Dict[str, object]) -> Path:
    item_dir = item_dir.resolve()
    artifact_name = str(event.get("artifact_name", ""))
    if artifact_name not in DELIVERABLE_NAMES or event.get("decision") != "passed":
        raise ValueError("只有七项固定产出的 passed 事件可以晋升")
    events = load_approval_events(item_dir)
    recorded = next((value for value in events if value.get("event_id") == event.get("event_id")), None)
    if recorded is None:
        raise ValueError("passed 事件尚未写入产出验收记录")
    digest = str(recorded.get("sha256", ""))
    latest = latest_artifact_decision(events, artifact_name, digest)
    if latest is None or latest.get("event_id") != recorded.get("event_id") or latest.get("decision") != "passed":
        raise ValueError("该候选的最新验收决定不是 passed")

    source = (item_dir / str(recorded["source_path"])).resolve()
    try:
        source.relative_to(item_dir)
    except ValueError as exc:
        raise ValueError("验收事件的候选路径已越出任务目录") from exc
    if not source.is_file() or _sha256_file(source) != digest:
        raise ValueError("候选文件缺失或哈希已变化，不能晋升")

    root_artifact = deliverable_root_path(item_dir, artifact_name)
    if root_artifact.exists():
        if not root_artifact.is_file():
            raise ValueError(f"一级固定产出路径不是文件：{root_artifact}")
        if _sha256_file(root_artifact) == digest:
            return root_artifact
    confirmed_at = datetime.fromisoformat(str(recorded["confirmed_at"]))
    temporary = root_artifact.with_name(root_artifact.name + f".tmp.{uuid.uuid4().hex}")
    archived_previous: Optional[Path] = None
    try:
        shutil.copyfile(source, temporary)
        if _sha256_file(temporary) != digest:
            raise OSError(f"晋升临时文件哈希校验失败：{source}")
        if root_artifact.exists():
            old_digest = _sha256_file(root_artifact)
            archived_previous = _unique_artifact_archive_path(
                item_dir, "已撤换产出", artifact_name, old_digest, confirmed_at
            )
            archived_previous.parent.mkdir(parents=True, exist_ok=True)
            root_artifact.replace(archived_previous)
        try:
            temporary.replace(root_artifact)
            if _sha256_file(root_artifact) != digest:
                raise OSError(f"晋升后哈希校验失败：{root_artifact}")
        except Exception as promote_error:
            rollback_error = None
            try:
                if root_artifact.exists() and root_artifact.is_file():
                    failed_digest = _sha256_file(root_artifact)
                    failed_target = _unique_artifact_archive_path(
                        item_dir, "晋升失败", artifact_name, failed_digest, confirmed_at
                    )
                    failed_target.parent.mkdir(parents=True, exist_ok=True)
                    root_artifact.replace(failed_target)
                if archived_previous is not None and archived_previous.exists():
                    archived_previous.replace(root_artifact)
            except Exception as exc:
                rollback_error = exc
            if rollback_error is not None:
                raise OSError(f"晋升失败且旧产出回滚失败：{rollback_error}") from promote_error
            raise
    finally:
        if temporary.exists():
            temporary.unlink()
    return root_artifact


def audit_promoted_outputs(
    item_dir: Path,
    dry_run: bool = False,
    now: Optional[datetime] = None,
) -> Dict[str, object]:
    item_dir = item_dir.resolve()
    if not item_dir.is_dir() or not ITEM_DIR_PATTERN.match(item_dir.name):
        raise ValueError(f"不是有效的单条任务目录：{item_dir}")
    audit_time = now or datetime.now().astimezone()
    if audit_time.utcoffset() is None:
        raise ValueError("审计时间必须包含时区")

    errors: List[Dict[str, object]] = []
    try:
        events = load_approval_events(item_dir)
    except (ValueError, KeyError, json.JSONDecodeError) as exc:
        events = []
        errors.append({"artifact_name": None, "error": str(exc)})

    valid = []
    demoted = []
    missing = []
    for artifact_name in sorted(DELIVERABLE_NAMES):
        try:
            root_artifact = deliverable_root_path(item_dir, artifact_name)
        except ValueError as exc:
            if artifact_name != "视频.mp4" or (item_dir / "标题.txt").exists():
                errors.append({"artifact_name": artifact_name, "error": str(exc)})
            missing.append(artifact_name)
            continue
        if not root_artifact.exists():
            missing.append(artifact_name)
            continue
        if not root_artifact.is_file():
            errors.append({"artifact_name": artifact_name, "error": "一级固定产出路径不是文件"})
            continue
        digest = _sha256_file(root_artifact)
        try:
            latest = latest_artifact_decision(events, artifact_name, digest)
        except (ValueError, KeyError) as exc:
            latest = None
            errors.append({"artifact_name": artifact_name, "error": str(exc)})
        if latest is not None and latest.get("decision") == "passed":
            valid.append({"artifact_name": artifact_name, "sha256": digest, "event": latest})
            continue
        target = _archive_root_artifact(
            item_dir,
            root_artifact,
            "未通过或待验收",
            audit_time,
            dry_run=dry_run,
        )
        demoted.append(
            {
                "artifact_name": artifact_name,
                "sha256": digest,
                "target": str(target),
                "latest_event": latest,
            }
        )

    expected_video = None
    try:
        expected_video = deliverable_root_path(item_dir, "视频.mp4")
    except ValueError:
        pass
    for stray_video in sorted(item_dir.glob("*.mp4"), key=lambda path: path.name.casefold()):
        if expected_video is not None and stray_video == expected_video:
            continue
        if not stray_video.is_file():
            errors.append({"artifact_name": "视频.mp4", "error": "一级视频产出路径不是文件"})
            continue
        digest = _sha256_file(stray_video)
        target = _archive_root_artifact(
            item_dir,
            stray_video,
            "已撤换产出",
            audit_time,
            dry_run=dry_run,
        )
        demoted.append(
            {
                "artifact_name": "视频.mp4",
                "physical_name": stray_video.name,
                "sha256": digest,
                "target": str(target),
                "latest_event": None,
            }
        )

    return {
        "item_dir": str(item_dir),
        "dry_run": dry_run,
        "promoted": [],
        "valid": valid,
        "demoted": demoted,
        "missing": missing,
        "errors": errors,
    }


def audit_batch_outputs(batch_dir: Path, dry_run: bool = False, video_ids: Optional[List[str]] = None) -> Dict[str, object]:
    batch_dir = batch_dir.resolve()
    if not batch_dir.is_dir():
        raise ValueError(f"批次目录不存在：{batch_dir}")
    item_dirs = sorted(
        (path for path in batch_dir.iterdir() if path.is_dir() and ITEM_DIR_PATTERN.match(path.name)),
        key=lambda path: path.name.casefold(),
    )
    if not item_dirs:
        raise ValueError(f"批次目录第一层没有 VNNN_ 单条任务目录：{batch_dir}")
    if video_ids is not None:
        item_dirs = [item for item in item_dirs if item.name.split("_", 1)[0] in video_ids]
    return {
        "batch_dir": str(batch_dir),
        "dry_run": dry_run,
        "items": [audit_promoted_outputs(item_dir, dry_run=dry_run) for item_dir in item_dirs],
    }


def _audit_result_has_errors(result: Dict[str, object]) -> bool:
    if result.get("errors"):
        return True
    items = result.get("items", [])
    return isinstance(items, list) and any(
        isinstance(item, dict) and _audit_result_has_errors(item) for item in items
    )


def validated_promoted_artifact_path(item_dir: Path, artifact_name: str) -> Optional[Path]:
    if artifact_name not in DELIVERABLE_NAMES:
        raise ValueError(f"未知产出名称：{artifact_name}")
    item_dir = item_dir.resolve()
    try:
        root_artifact = deliverable_root_path(item_dir, artifact_name)
    except ValueError:
        return None
    if not root_artifact.is_file():
        return None
    try:
        digest = _sha256_file(root_artifact)
        latest = latest_artifact_decision(load_approval_events(item_dir), artifact_name, digest)
    except (ValueError, KeyError, json.JSONDecodeError):
        return None
    return root_artifact if latest is not None and latest.get("decision") == "passed" else None


def classify_legacy_entry(item_dir: Path, path: Path) -> Optional[Tuple[str, Path]]:
    expected_video = None
    try:
        expected_video = deliverable_root_path(item_dir, "视频.mp4")
    except ValueError:
        pass
    if path.name in DELIVERABLE_NAMES or path.name == WORK_DIR_NAME or path == expected_video:
        return None
    if path.name == "发布正文.md":
        return "历史版本", Path("旧格式") / path.name
    if path.name in HISTORY_DIR_NAMES:
        return "历史版本", Path(path.name)
    if path.name.startswith(TASK_STATE_PREFIXES):
        return "任务状态", Path(path.name)
    if path.name.startswith(REVIEW_PREFIXES):
        return "验收记录", Path(path.name)
    if path.is_file() and (
        (path.suffix.casefold() == ".mp4" and path.name != "视频.mp4")
        or path.name.startswith("封面图_")
    ):
        return "历史版本", Path(path.name)
    return "生成过程", Path(path.name)


def _entry_manifest(path: Path) -> Tuple[Tuple[str, str, str], ...]:
    if path.is_file():
        return ((path.name, "file", hashlib.sha256(path.read_bytes()).hexdigest()),)
    if not path.is_dir():
        return ()
    manifest = []
    for child in sorted(path.rglob("*"), key=lambda value: value.relative_to(path).as_posix().casefold()):
        relative = child.relative_to(path).as_posix()
        if child.is_dir():
            manifest.append((relative, "dir", ""))
        elif child.is_file():
            manifest.append((relative, "file", hashlib.sha256(child.read_bytes()).hexdigest()))
        else:
            manifest.append((relative, "other", ""))
    return tuple(manifest)


def _same_entry(source: Path, target: Path) -> bool:
    return source.is_file() == target.is_file() and source.is_dir() == target.is_dir() and _entry_manifest(source) == _entry_manifest(target)


def _next_duplicate_target(item_dir: Path, source: Path, reserved: set) -> Path:
    duplicate_root = work_path(item_dir, "历史版本", "重复项")
    candidate = duplicate_root / source.name
    counter = 2
    while candidate.exists() or candidate in reserved:
        if source.is_file():
            candidate = duplicate_root / f"{source.stem}_重复{counter}{source.suffix}"
        else:
            candidate = duplicate_root / f"{source.name}_重复{counter}"
        counter += 1
    return candidate


def organize_item_dir(item_dir: Path, dry_run: bool = False) -> Dict[str, object]:
    item_dir = item_dir.resolve()
    if not item_dir.is_dir():
        raise ValueError(f"单条任务目录不存在：{item_dir}")
    if not ITEM_DIR_PATTERN.match(item_dir.name):
        raise ValueError(f"不是单条任务目录，名称必须以 VNNN_ 开头：{item_dir}")

    output_audit = audit_promoted_outputs(item_dir, dry_run=True)
    plan = []
    duplicates = []
    reserved_duplicate_targets = set()
    conflicts = []
    for source in sorted(item_dir.iterdir(), key=lambda path: path.name.casefold()):
        classification = classify_legacy_entry(item_dir, source)
        if classification is None:
            continue
        category, relative_target = classification
        target = work_path(item_dir, category, str(relative_target))
        if target.exists():
            if _same_entry(source, target):
                duplicate_target = _next_duplicate_target(item_dir, source, reserved_duplicate_targets)
                reserved_duplicate_targets.add(duplicate_target)
                duplicates.append((source, target, duplicate_target))
                continue
            raise FileExistsError(f"目标已存在且内容不同，未移动任何文件：{source.name} -> {target}")
        plan.append((source, target))

    if not dry_run:
        output_audit = audit_promoted_outputs(item_dir)
        ensure_work_dirs(item_dir)
        plan = [(source, target) for source, target in plan if source.exists()]
        duplicates = [entry for entry in duplicates if entry[0].exists()]
        for source, target in plan:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(source), str(target))
        for source, _existing, duplicate_target in duplicates:
            duplicate_target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(source), str(duplicate_target))

    planned_sources = {source for source, _target in plan} | {source for source, _existing, _target in duplicates}
    if dry_run:
        remaining_forbidden = [
            path.name
            for path in item_dir.iterdir()
            if classify_legacy_entry(item_dir, path) is not None and path not in planned_sources
        ]
    else:
        remaining_forbidden = [
            path.name for path in item_dir.iterdir() if classify_legacy_entry(item_dir, path) is not None
        ]
    audit_error_names = [
        str(error.get("artifact_name"))
        for error in output_audit.get("errors", [])
        if isinstance(error, dict) and error.get("artifact_name")
    ]
    remaining_forbidden = sorted(set(remaining_forbidden + audit_error_names))

    return {
        "item_dir": str(item_dir),
        "dry_run": dry_run,
        "moved": [{"source": str(source), "target": str(target)} for source, target in plan],
        "duplicates": [
            {"source": str(source), "existing": str(existing), "archived": str(duplicate_target)}
            for source, existing, duplicate_target in duplicates
        ],
        "unchanged": sorted(name for name in DELIVERABLE_NAMES if (item_dir / name).exists()),
        "conflicts": conflicts,
        "root_clean": not remaining_forbidden and not _audit_result_has_errors(output_audit),
        "remaining_forbidden": remaining_forbidden,
        "output_audit": output_audit,
    }


def organize_batch_dir(batch_dir: Path, dry_run: bool = False) -> Dict[str, object]:
    batch_dir = batch_dir.resolve()
    if not batch_dir.is_dir():
        raise ValueError(f"批次目录不存在：{batch_dir}")
    item_dirs = sorted(
        (path for path in batch_dir.iterdir() if path.is_dir() and ITEM_DIR_PATTERN.match(path.name)),
        key=lambda path: path.name.casefold(),
    )
    if not item_dirs:
        raise ValueError(f"批次目录第一层没有 VNNN_ 单条任务目录：{batch_dir}")
    return {
        "batch_dir": str(batch_dir),
        "dry_run": dry_run,
        "items": [organize_item_dir(item_dir, dry_run=dry_run) for item_dir in item_dirs],
    }


def sanitize_component(value: str, limit: int = 36) -> str:
    cleaned = WINDOWS_FORBIDDEN.sub("_", value).strip().rstrip(".")
    cleaned = re.sub(r"\s+", "_", cleaned)
    return (cleaned or "未命名")[:limit]


def scan_product_images(product_dir: Path) -> Tuple[Path, ...]:
    product_dir = product_dir.resolve()
    if not product_dir.is_dir():
        raise ValueError(f"产品文件夹不存在：{product_dir}")
    return tuple(
        sorted(
            (
                path.resolve()
                for path in product_dir.iterdir()
                if path.is_file() and path.suffix.lower() in IMAGE_SUFFIXES
            ),
            key=lambda path: path.name.casefold(),
        )
    )


def scan_cover_references(reference_dir: Path) -> Tuple[Path, ...]:
    reference_dir = reference_dir.resolve()
    if not reference_dir.is_dir():
        raise ValueError(f"封面图参考文件夹不存在：{reference_dir}")
    return tuple(
        sorted(
            (
                path.resolve()
                for path in reference_dir.iterdir()
                if path.is_file() and path.suffix.lower() in IMAGE_SUFFIXES
            ),
            key=lambda path: path.name.casefold(),
        )
    )


def allocate_video_points(selling_points: Sequence[str], total_videos: int) -> Tuple[str, ...]:
    points = tuple(point.strip() for point in selling_points if point.strip())
    if not points:
        raise ValueError("至少提供一个卖点")
    if total_videos <= 0:
        raise ValueError("视频总数必须大于 0")
    base, remainder = divmod(total_videos, len(points))
    allocation: List[str] = []
    for index, point in enumerate(points):
        allocation.extend([point] * (base + (1 if index < remainder else 0)))
    return tuple(allocation)


def _next_batch_dir(product_dir: Path, now: datetime) -> Path:
    output_root = product_dir / "生成视频"
    output_root.mkdir(parents=True, exist_ok=True)
    prefix = now.strftime("%Y%m%d")
    numbers = []
    for path in output_root.iterdir():
        match = re.fullmatch(rf"{prefix}_批次(\d{{3}})", path.name) if path.is_dir() else None
        if match:
            numbers.append(int(match.group(1)))
    return output_root / f"{prefix}_批次{(max(numbers, default=0) + 1):03d}"


def _product_id(product_name: str) -> str:
    digest = hashlib.sha256(product_name.strip().encode("utf-8")).hexdigest()[:10]
    return f"{sanitize_component(product_name, 24)}_{digest}"


def capture_learning_issue(
    *,
    knowledge_dir: Path,
    batch_dir: Path,
    video_id: str,
    node: str,
    user_feedback: str,
    symptom: str,
    root_cause: str,
    solution: str,
    prevention_rule: str,
    validation_method: str,
    validation_expected: str,
    evidence_paths: Sequence[Path] = (),
    model: Optional[str] = None,
    channel: Optional[str] = None,
    now: Optional[datetime] = None,
) -> Path:
    if node not in LEARNING_NODES:
        raise ValueError(f"未知学习节点：{node}")
    required = {
        "用户反馈": user_feedback,
        "失败表现": symptom,
        "根因": root_cause,
        "解决方案": solution,
        "预防规则": prevention_rule,
        "验证方法": validation_method,
        "预期结果": validation_expected,
    }
    empty = [name for name, value in required.items() if not str(value).strip()]
    if empty:
        raise ValueError("自动复盘缺少：" + "、".join(empty))

    batch_dir = batch_dir.resolve()
    confirmation = read_json(batch_dir / "启动确认单.json")
    if confirmation.get("run_mode") != "learning":
        raise ValueError("只有学习模式可以记录新的候选经验")

    timestamp = (now or datetime.now().astimezone()).isoformat()
    fingerprint_source = "|".join(
        (
            str(confirmation.get("product_name", "")),
            node,
            video_id,
            user_feedback.strip(),
            symptom.strip(),
        )
    )
    issue_id = "issue_" + hashlib.sha256(fingerprint_source.encode("utf-8")).hexdigest()[:16]
    evidence = []
    for source in evidence_paths:
        resolved = source.resolve()
        if not resolved.is_file():
            raise ValueError(f"学习证据文件不存在：{resolved}")
        evidence.append({"path": str(resolved), "sha256": _sha256_file(resolved)})

    product_name = str(confirmation.get("product_name", ""))
    value = {
        "issue_id": issue_id,
        "status": "candidate",
        "scope": {
            "product_id": _product_id(product_name) if product_name else None,
            "node": node,
            "model": model,
            "channel": channel,
        },
        "user_feedback": user_feedback.strip(),
        "symptom": symptom.strip(),
        "root_cause": root_cause.strip(),
        "solution": solution.strip(),
        "prevention_rule": prevention_rule.strip(),
        "validation": {
            "method": validation_method.strip(),
            "expected": validation_expected.strip(),
            "result": "pending",
        },
        "evidence": evidence,
        "source_batch": str(batch_dir),
        "source_video_id": video_id,
        "created_at": timestamp,
        "updated_at": timestamp,
    }
    knowledge_dir = knowledge_dir.resolve()
    target = knowledge_dir / "候选经验" / f"{issue_id}.json"
    with _learning_store_lock(knowledge_dir):
        existing = read_json(target)
        if existing is not None:
            existing.setdefault("duplicate_events", []).append(
                {"at": timestamp, "evidence": evidence}
            )
            existing["updated_at"] = timestamp
            atomic_write_json(target, existing)
        else:
            atomic_write_json(target, value)
    return target


def _learning_scope_key(scope: dict) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str]]:
    return tuple(scope.get(key) for key in ("product_id", "node", "model", "channel"))


def _validate_learning_issue_unlocked(
    *,
    knowledge_dir: Path,
    batch_dir: Path,
    video_id: str,
    issue_id: str,
    result: str,
    verified_candidate: Optional[Path],
    now: Optional[datetime] = None,
) -> Optional[Path]:
    if result not in {"passed", "failed", "inconclusive"}:
        raise ValueError("学习验证结果无效")

    knowledge_dir = knowledge_dir.resolve()
    batch_dir = batch_dir.resolve()
    confirmation = read_json(batch_dir / "启动确认单.json")
    if confirmation.get("run_mode") != "learning":
        raise ValueError("只有学习模式可以验证并升级候选经验")

    issue_path = knowledge_dir / "候选经验" / f"{issue_id}.json"
    issue = read_json(issue_path)
    if not issue:
        raise ValueError(f"候选经验不存在：{issue_id}")
    if issue.get("source_video_id") != video_id:
        raise ValueError("候选经验与视频 ID 不匹配")

    item = _find_item(batch_dir, video_id)
    task = read_json(work_path(item, "任务状态", "任务信息.json"))
    if int(task.get("retry_count", 0)) != 1:
        raise ValueError("只有 V02 唯一一次重跑可以验证候选经验")

    timestamp = (now or datetime.now().astimezone()).isoformat()
    issue["validation"]["result"] = result
    issue["validation"]["verified_at"] = timestamp
    issue["updated_at"] = timestamp
    if result != "passed":
        issue["status"] = result
        atomic_write_json(issue_path, issue)
        return None

    if verified_candidate is None:
        raise ValueError("验证通过必须绑定实际候选文件")
    verified_candidate = verified_candidate.resolve()
    if not verified_candidate.is_file():
        raise ValueError(f"验证候选不存在：{verified_candidate}")
    digest = _sha256_file(verified_candidate)
    scope = issue["scope"]
    scope_key = _learning_scope_key(scope)
    rule_seed = "|".join(str(value or "*") for value in scope_key)
    rule_id = "rule_" + hashlib.sha256(
        (rule_seed + "|" + issue["prevention_rule"]).encode("utf-8")
    ).hexdigest()[:16]
    rules_dir = knowledge_dir / "正式规则"
    existing_rules = []
    if rules_dir.exists():
        for path in sorted(rules_dir.glob("*.json")):
            value = read_json(path)
            if value and _learning_scope_key(value.get("scope", {})) == scope_key:
                existing_rules.append((path, value))
    version = max((int(value.get("version", 0)) for _, value in existing_rules), default=0) + 1
    target = rules_dir / f"{rule_id}.json"
    previous_same_rule = read_json(target, {})
    rule = {
        "rule_id": rule_id,
        "version": version,
        "status": "active",
        "scope": scope,
        "trigger": issue["symptom"],
        "required_action": issue["prevention_rule"],
        "validation_check": issue["validation"]["expected"],
        "source_issue_id": issue_id,
        "source_batch": str(batch_dir),
        "source_video_id": video_id,
        "verified_candidate_sha256": digest,
        "verified_at": timestamp,
        "hit_count": int(previous_same_rule.get("hit_count", 0)),
        "last_hit_at": previous_same_rule.get("last_hit_at"),
    }
    for path, value in existing_rules:
        if path == target or value.get("status") != "active":
            continue
        value["status"] = "superseded"
        value["superseded_by"] = rule_id
        value["superseded_at"] = timestamp
        atomic_write_json(path, value)
    atomic_write_json(target, rule)

    issue["status"] = "promoted"
    issue["promoted_rule_id"] = rule_id
    atomic_write_json(issue_path, issue)
    return target


def validate_learning_issue(
    *,
    knowledge_dir: Path,
    batch_dir: Path,
    video_id: str,
    issue_id: str,
    result: str,
    verified_candidate: Optional[Path],
    now: Optional[datetime] = None,
) -> Optional[Path]:
    with _learning_store_lock(knowledge_dir):
        return _validate_learning_issue_unlocked(
            knowledge_dir=knowledge_dir,
            batch_dir=batch_dir,
            video_id=video_id,
            issue_id=issue_id,
            result=result,
            verified_candidate=verified_candidate,
            now=now,
        )


def load_matching_rules(
    knowledge_dir: Path,
    *,
    product_id: Optional[str],
    node: Optional[str],
    model: Optional[str] = None,
    channel: Optional[str] = None,
) -> List[dict]:
    rules_dir = knowledge_dir.resolve() / "正式规则"
    matched = []
    paths = sorted(rules_dir.glob("*.json")) if rules_dir.exists() else ()
    for path in paths:
        rule = read_json(path)
        if not rule or rule.get("status") != "active":
            continue
        scope = rule.get("scope", {})
        checks = (
            ("product_id", product_id),
            ("node", node),
            ("model", model),
            ("channel", channel),
        )
        if any(
            value is not None and scope.get(key) not in (None, value)
            for key, value in checks
        ):
            continue
        rule["_specificity"] = sum(scope.get(key) is not None for key, _ in checks)
        matched.append(rule)
    matched.sort(
        key=lambda value: (
            value["_specificity"],
            value.get("verified_at", ""),
            value["rule_id"],
        ),
        reverse=True,
    )
    for rule in matched:
        rule.pop("_specificity", None)
    return matched


def prepare_node_rules(
    *,
    knowledge_dir: Path,
    batch_dir: Path,
    video_id: str,
    node: str,
    model: Optional[str] = None,
    channel: Optional[str] = None,
    now: Optional[datetime] = None,
) -> Path:
    if node not in LEARNING_NODES:
        raise ValueError(f"未知学习节点：{node}")
    knowledge_dir = knowledge_dir.resolve()
    batch_dir = batch_dir.resolve()
    item = _find_item(batch_dir, video_id)
    confirmation = read_json(batch_dir / "启动确认单.json")
    product_id = confirmation.get("product_id")
    if not product_id and confirmation.get("product_name"):
        product_id = _product_id(str(confirmation["product_name"]))
    timestamp = (now or datetime.now().astimezone()).isoformat()
    target = work_path(item, "任务状态", f"生效规则_{node}.json")

    with _learning_store_lock(knowledge_dir):
        matched = load_matching_rules(
            knowledge_dir,
            product_id=product_id,
            node=node,
            model=model,
            channel=channel,
        )
        for rule in matched:
            path = knowledge_dir / "正式规则" / f"{rule['rule_id']}.json"
            current = read_json(path)
            current["hit_count"] = int(current.get("hit_count", 0)) + 1
            current["last_hit_at"] = timestamp
            atomic_write_json(path, current)
        atomic_write_json(
            target,
            {
                "video_id": video_id,
                "node": node,
                "model": model,
                "channel": channel,
                "prepared_at": timestamp,
                "rules": matched,
            },
        )
    return target


def _record_selling_points(
    knowledge_dir: Path,
    product_name: str,
    product_dir: Path,
    selling_points: Sequence[str],
    now: datetime,
) -> Path:
    library_dir = knowledge_dir.resolve() / "产品卖点库"
    library_path = library_dir / f"{_product_id(product_name)}.json"
    value = read_json(
        library_path,
        {
            "product_name": product_name,
            "product_id": _product_id(product_name),
            "last_product_path": str(product_dir.resolve()),
            "selling_points": [],
        },
    )
    existing = {entry["content"]: entry for entry in value["selling_points"]}
    timestamp = now.astimezone(timezone.utc).isoformat()
    for point in dict.fromkeys(point.strip() for point in selling_points if point.strip()):
        if point in existing:
            existing[point]["last_used_at"] = timestamp
            existing[point]["use_count"] = int(existing[point].get("use_count", 0)) + 1
        else:
            entry = {
                "category": "待本次内容分析分类",
                "content": point,
                "first_used_at": timestamp,
                "last_used_at": timestamp,
                "use_count": 1,
            }
            value["selling_points"].append(entry)
            existing[point] = entry
    value["last_product_path"] = str(product_dir.resolve())
    value["updated_at"] = timestamp
    value["selling_points"].sort(key=lambda entry: entry["content"])
    atomic_write_json(library_path, value)
    return library_path


def initialize_batch(
    *,
    product_dir: Path,
    product_name: str,
    selling_points: Sequence[str],
    total_videos: int,
    run_mode: str,
    resolution: str,
    max_budget_yuan: str,
    cover_reference_dir: Path,
    knowledge_dir: Path,
    now: Optional[datetime] = None,
    text_provider: str = "任务开始前确认",
    image_provider: str,
    image_api_config: object | None = None,
) -> BatchContext:
    if run_mode not in {"learning", "auto"}:
        raise ValueError("运行模式只能是 learning 或 auto")
    if resolution not in {"768P", "2K"}:
        raise ValueError("分辨率只能是 768P 或 2K")
    policy_module = _load_policy_module()
    image_provider = policy_module.normalize_image_provider(image_provider)
    if image_provider == "third_party_api":
        if image_api_config is None:
            image_api_config = _load_api_config_module().image_api_runtime_config()
        normalized_image_api = policy_module.normalize_image_api_config(image_api_config)
    elif image_api_config not in (None, {}):
        raise ValueError("非第三方 API 图片渠道不得携带第三方 API 配置")
    else:
        normalized_image_api = {}
    try:
        if Decimal(max_budget_yuan) <= 0:
            raise ValueError("本批次最高预算必须大于 0")
    except InvalidOperation as exc:
        raise ValueError("预算必须是有效金额") from exc

    product_dir = product_dir.resolve()
    images = scan_product_images(product_dir)
    if not images:
        raise ValueError("产品文件夹第一层没有可用图片")
    cover_refs = scan_cover_references(cover_reference_dir)
    if not cover_refs:
        raise ValueError("封面图参考文件夹第一层没有可用图片")
    allocated = allocate_video_points(selling_points, total_videos)
    now = now or datetime.now().astimezone()
    batch_dir = _next_batch_dir(product_dir, now)
    batch_dir.mkdir(parents=True, exist_ok=False)

    items: List[BatchItem] = []
    task_rows = []
    for index, point in enumerate(allocated, start=1):
        video_id = f"V{index:03d}"
        project_dir = batch_dir / f"{video_id}_{sanitize_component(point, 20)}_待生成"
        ensure_work_dirs(project_dir)
        (work_path(project_dir, "历史版本", "视频版本") / "V01_初次生成").mkdir(parents=True)
        work_path(project_dir, "历史版本", "失败版本").mkdir(parents=True)
        task_info = {
            "video_id": video_id,
            "selling_point": point,
            "status": "CREATED",
            "task_id": None,
            "request_id": None,
            "request_hash": None,
            "retry_count": 0,
            "project_dir": str(project_dir.resolve()),
        }
        atomic_write_json(work_path(project_dir, "任务状态", "任务信息.json"), task_info)
        task_rows.append(task_info)
        items.append(BatchItem(video_id, point, project_dir))

    library_path = _record_selling_points(
        knowledge_dir=knowledge_dir,
        product_name=product_name,
        product_dir=product_dir,
        selling_points=selling_points,
        now=now,
    )
    product_id = _product_id(product_name)
    matched_rules = load_matching_rules(
        knowledge_dir,
        product_id=product_id,
        node=None,
        model=None,
        channel=None,
    )
    confirmation = {
        "confirmed": False,
        "confirmation_scope": "任务开始前一次性确认；运行中不补问普通配置",
        "product_dir": str(product_dir),
        "product_name": product_name,
        "product_id": product_id,
        "product_images": [str(path) for path in images],
        "selling_points": list(selling_points),
        "total_videos": total_videos,
        "allocation": {point: allocated.count(point) for point in dict.fromkeys(allocated)},
        "run_mode": run_mode,
        "startup_authorization": (
            "initial_user_reply"
            if run_mode == "auto"
            else "learning_review_required"
        ),
        "text_provider": text_provider,
        "image_provider": image_provider,
        "image_api_config": normalized_image_api,
        "cover_reference_dir": str(cover_reference_dir.resolve()),
        "video_provider": "AutoDL.Art MiniMax-H3",
        "duration_seconds": 15,
        "ratio": "9:16",
        "resolution": resolution,
        "aigc_watermark": False,
        "audio": "MiniMax-H3 原生对白；按人物清单匹配音色；轻微环境声；无 BGM",
        "image_max_attempts": 2,
        "video_max_reruns": 1,
        "concurrency": 1,
        "poll_interval_seconds": 20,
        "poll_timeout_seconds": 3600,
        "max_budget_yuan": str(Decimal(max_budget_yuan)),
        "live_price": "任务开始前查询并填写",
        "knowledge_library": str(library_path.resolve()),
        "formal_rules_library": str((knowledge_dir.resolve() / "正式规则")),
        "matched_learning_rules": [
            {
                "rule_id": rule["rule_id"],
                "node": rule.get("scope", {}).get("node"),
                "required_action": rule["required_action"],
            }
            for rule in matched_rules
        ],
        "created_at": now.isoformat(),
    }
    atomic_write_json(batch_dir / "启动确认单.json", confirmation)
    atomic_write_json(batch_dir / "批次任务表.json", {"items": task_rows})
    startup_status = (
        "自动模式已由首次回复授权 V01，等待逐条价格后连续执行"
        if run_mode == "auto"
        else "等待学习模式启动确认"
    )
    atomic_write_text(batch_dir / "批次汇总.md", f"# 批次汇总\n\n状态：{startup_status}\n")
    return BatchContext(batch_dir, images, items)


def _han_count(value: str) -> int:
    return sum("\u4e00" <= char <= "\u9fff" for char in value)


def _closing_is_valid(dialogue: str, product_name: str) -> bool:
    used = any(term in dialogue for term in ("买了", "用了", "使用了", "换了"))
    has_product = product_name in dialogue
    after = "后" in dialogue
    benefit = any(term in dialogue for term in IMPROVEMENT_TERMS)
    cta = any(term in dialogue for term in CTA_TERMS)
    return used and has_product and after and benefit and cta


def _has_forbidden_product_appearance(text: object) -> bool:
    """Use the central prompt contract without compiling model content early."""
    path = Path(__file__).with_name("generation_prompt_contract.py")
    spec = importlib.util.spec_from_file_location(
        "product_video_generation_prompt_contract", path
    )
    if spec is None or spec.loader is None:
        raise RuntimeError("无法加载 generation_prompt_contract.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return bool(module.has_forbidden_product_appearance(text))


def validate_content_package(package: Dict[str, object], profile: Dict[str, object]) -> List[str]:
    issues: List[str] = []
    if not isinstance(package, dict):
        return ["content.object_required"]
    # Validate shapes before semantic checks; model JSON is untrusted input.
    for key in ("publish_title", "cover_title", "storyboard_prompt", "last_frame_prompt", "video_prompt", "publish_body"):
        if not isinstance(package.get(key, ""), str):
            issues.append(f"content.{key}.string_required")
    for key in ("storyboard_people", "hashtags"):
        values = package.get(key)
        if not isinstance(values, list) or any(not isinstance(v, str) for v in values):
            issues.append(f"content.{key}.string_list_required")
    for key in ("people", "script_segments"):
        values = package.get(key)
        if not isinstance(values, list) or any(not isinstance(v, dict) for v in values):
            issues.append(f"content.{key}.object_list_required")
    if issues:
        return issues
    for person in package["people"]:
        if any(not isinstance(person.get(key), str) or not person[key].strip() for key in ("id", "identity", "gender", "age_feel", "position", "action")) or type(person.get("speaks")) is not bool:
            issues.append("people.field_types")
    for segment in package["script_segments"]:
        if any(type(segment.get(key)) not in (int, float) for key in ("start", "end")) or any(not isinstance(segment.get(key), str) or not segment[key].strip() for key in ("speaker_id", "dialogue")):
            issues.append("script.field_types")
    if issues:
        return list(dict.fromkeys(issues))
    if not package.get("storyboard_prompt", "").strip():
        issues.append("content.storyboard_prompt_missing")
    if any(
        _has_forbidden_product_appearance(package[key])
        for key in ("storyboard_prompt", "last_frame_prompt", "video_prompt")
    ):
        issues.append("product.appearance_description_forbidden")

    title = str(package.get("publish_title", ""))
    required_title_term = str(profile["required_title_term"])
    if required_title_term not in title:
        issues.append("title.required_term")
    title_chars = _han_count(title)
    if not 12 <= title_chars <= 28:
        issues.append("title.length")

    cover_title = str(package.get("cover_title", ""))
    if not int(profile["cover_title_min_chars"]) <= _han_count(cover_title) <= int(profile["cover_title_max_chars"]):
        issues.append("cover_title.length")

    people = package.get("people") if isinstance(package.get("people"), list) else []
    required_person_fields = {"id", "identity", "gender", "age_feel", "position", "action", "speaks"}
    if not people or any(not required_person_fields <= set(person) for person in people if isinstance(person, dict)):
        issues.append("people.fields_missing")
    people_ids = [str(person.get("id")) for person in people if isinstance(person, dict)]
    if len(people_ids) != 2 or len(set(people_ids)) != 2:
        issues.append("people.exactly_two_required")
    storyboard_people = [str(value) for value in package.get("storyboard_people", [])]
    if people_ids != storyboard_people:
        issues.append("people.mismatch")

    segments = package.get("script_segments") if isinstance(package.get("script_segments"), list) else []
    segment_ranges = [(segment.get("start"), segment.get("end")) for segment in segments if isinstance(segment, dict)]
    if segment_ranges != FIXED_SEGMENTS:
        issues.append("script.timeline")
    if any(str(segment.get("speaker_id")) not in people_ids for segment in segments if isinstance(segment, dict)):
        issues.append("people.offscreen_speaker")
    segment_speakers = {
        str(segment.get("speaker_id")) for segment in segments if isinstance(segment, dict) and segment.get("speaker_id")
    }
    if len(segment_speakers) != 2 or segment_speakers != set(people_ids):
        issues.append("script.exactly_two_speakers_required")
    closing = str(segments[-1].get("dialogue", "")) if segments and isinstance(segments[-1], dict) else ""
    if not _closing_is_valid(closing, str(profile["closing_product_name"])):
        issues.append("closing.missing_improvement_and_cta")

    video_prompt = str(package.get("video_prompt", ""))
    if not str(package.get("last_frame_prompt", "")).strip():
        issues.append("content.tail_frame_prompt_missing")
    if any(term.casefold() in video_prompt.casefold() for term in TURNING_TERMS):
        issues.append("motion.turning_forbidden")
    if any(term in video_prompt for term in FOLDING_PROCESS_TERMS):
        issues.append("folding.dynamic_process_forbidden")
    if not any(term in video_prompt for term in ("一镜到底", "固定镜头", "同一个镜头")):
        issues.append("shot.single_required")
    if any(
        rule not in video_prompt
        for rule in ("一镜到底", "连续平稳运镜", "完整双人对话口播")
    ):
        issues.append("shot.full_duration_rules_missing")

    body = str(package.get("publish_body", ""))
    body_chars = _han_count(body)
    if not int(profile["body_min_chars"]) <= body_chars <= int(profile["body_max_chars"]):
        issues.append("body.length")
    if list(package.get("hashtags", [])) != list(profile["fixed_hashtags"]):
        issues.append("body.hashtags")

    return list(dict.fromkeys(issues))


def _write_candidate_preserving_previous(item_dir: Path, filename: str, text: str, now: datetime) -> None:
    target = work_path(item_dir, "生成过程", filename)
    encoded = text.encode("utf-8")
    new_digest = hashlib.sha256(encoded).hexdigest()
    old_digest = ""
    if target.exists():
        if not target.is_file():
            raise ValueError(f"候选路径不是普通文件：{target}")
        old_digest = _sha256_file(target)
        if old_digest == new_digest:
            return
    temporary = target.with_name(target.name + f".tmp.{uuid.uuid4().hex}")
    archived_previous: Optional[Path] = None
    try:
        temporary.parent.mkdir(parents=True, exist_ok=True)
        temporary.write_bytes(encoded)
        if _sha256_file(temporary) != new_digest:
            raise OSError(f"候选临时文件哈希校验失败：{target}")
        if target.exists():
            archived_previous = _unique_artifact_archive_path(item_dir, "候选版本", filename, old_digest, now)
            archived_previous.parent.mkdir(parents=True, exist_ok=True)
            target.replace(archived_previous)
        try:
            temporary.replace(target)
        except Exception as write_error:
            if archived_previous is not None and archived_previous.exists() and not target.exists():
                try:
                    archived_previous.replace(target)
                except Exception as rollback_error:
                    raise OSError(f"候选更新失败且旧候选回滚失败：{rollback_error}") from write_error
            raise
    finally:
        if temporary.exists():
            temporary.unlink()
    if _sha256_file(target) != new_digest:
        raise OSError(f"候选文件写入后哈希校验失败：{target}")


def save_content_package(item_dir: Path, package_path: Path, profile_path: Path) -> None:
    package = read_json(package_path)
    profile = read_json(profile_path)
    issues = validate_content_package(package, profile)
    if issues:
        raise ValueError("内容校验失败：" + ", ".join(issues))
    ensure_work_dirs(item_dir)
    now = datetime.now().astimezone()
    _write_candidate_preserving_previous(
        item_dir,
        "策划内容.json",
        json.dumps(package, ensure_ascii=False, indent=2),
        now,
    )
    _write_candidate_preserving_previous(
        item_dir,
        "标题.txt",
        f"发布标题：{package['publish_title']}\n封面标题：{package['cover_title']}\n",
        now,
    )
    _write_candidate_preserving_previous(item_dir, "分镜提示词.txt", str(package["storyboard_prompt"]), now)
    _write_candidate_preserving_previous(item_dir, "合理尾帧提示词.txt", str(package["last_frame_prompt"]), now)
    _write_candidate_preserving_previous(item_dir, "视频提示词.txt", str(package["video_prompt"]), now)
    _write_candidate_preserving_previous(item_dir, "封面标题.txt", str(package["cover_title"]), now)
    _write_candidate_preserving_previous(
        item_dir, "封面提示词.txt",
        "竖屏9:16，使用渠道支持的原生分辨率。参考分镜及产品图保持人物与产品结构，参考风格图生成完整电商封面。"
        + "准确绘制标题：" + str(package["cover_title"]) + "。不要其他文字。", now,
    )
    _write_candidate_preserving_previous(item_dir, "发布正文.txt", f"{package['publish_body']}\n", now)
    _write_candidate_preserving_previous(item_dir, "话题标签.txt", " ".join(package["hashtags"]) + "\n", now)


def _find_item(batch_dir: Path, video_id: str) -> Path:
    matches = [path for path in batch_dir.iterdir() if path.is_dir() and path.name.startswith(video_id + "_")]
    if len(matches) != 1:
        raise ValueError(f"无法唯一定位视频项目：{video_id}")
    return matches[0]


def record_task(
    batch_dir: Path,
    video_id: str,
    task_id: str,
    *,
    request_id: Optional[str] = None,
    request_hash: Optional[str] = None,
    status: str = "SUBMITTED",
    estimated_cost_yuan: Optional[str] = None,
) -> None:
    item_dir = _find_item(batch_dir, video_id)
    task_path = work_path(item_dir, "任务状态", "任务信息.json")
    task = read_json(read_compatible_path(item_dir, "任务状态", "任务信息.json"), {})
    if task.get("task_id") and task["task_id"] != task_id:
        raise ValueError("该视频已记录其他 task_id，禁止覆盖")
    task.update(
        {
            "task_id": task_id,
            "request_id": request_id,
            "request_hash": request_hash,
            "submission_pending": False,
            "status": status,
            "estimated_cost_yuan": estimated_cost_yuan,
            "updated_at": datetime.now().astimezone().isoformat(),
        }
    )
    atomic_write_json(task_path, task)
    table_path = batch_dir / "批次任务表.json"
    table = read_json(table_path, {"items": []})
    for row in table["items"]:
        if row["video_id"] == video_id:
            row.update(task)
            break
    atomic_write_json(table_path, table)


def start_rerun(batch_dir: Path, video_id: str, now: Optional[datetime] = None) -> Path:
    batch_dir = batch_dir.resolve()
    item_dir = _find_item(batch_dir, video_id)
    task_path = work_path(item_dir, "任务状态", "任务信息.json")
    task = read_json(read_compatible_path(item_dir, "任务状态", "任务信息.json"), {})
    if int(task.get("retry_count", 0)) != 0:
        raise ValueError("V02 是唯一一次重跑，禁止再次创建重跑")
    previous_submission = {
        key: task.get(key)
        for key in ("task_id", "request_id", "request_hash", "estimated_cost_yuan")
        if task.get(key) is not None
    }
    if previous_submission:
        task.setdefault("submission_history", []).append(
            {"version": "V01", **previous_submission}
        )
    task.update(
        {
            "task_id": None,
            "request_id": None,
            "request_hash": None,
            "estimated_cost_yuan": None,
        }
    )
    task["retry_count"] = 1
    task["status"] = "V02_READY"
    task["rerun_started_at"] = (now or datetime.now().astimezone()).isoformat()
    atomic_write_json(task_path, task)
    version_dir = work_path(item_dir, "历史版本", "视频版本/V02_唯一一次重跑")
    version_dir.mkdir(parents=True, exist_ok=True)

    table_path = batch_dir / "批次任务表.json"
    table = read_json(table_path, {"items": []})
    found = False
    for row in table["items"]:
        if row.get("video_id") == video_id:
            row.update(task)
            found = True
            break
    if not found:
        table["items"].append(task)
    atomic_write_json(table_path, table)
    return task_path


def _safe_file_url(item_dir: Path, filename: str) -> str:
    path = validated_promoted_artifact_path(item_dir, filename)
    return quote(f"{item_dir.name}/{path.name}") if path is not None else ""


def _review_candidate_path(item_dir: Path, artifact_name: str) -> Optional[Path]:
    names = {
        "标题.txt": ("标题.txt",),
        "封面图.png": ("封面候选.png", "候选封面.png", "封面图.png"),
        "视频.mp4": ("视频候选.mp4", "候选视频.mp4"),
    }.get(artifact_name, ())
    process_dir = work_path(item_dir, "生成过程", "placeholder").parent
    for name in names:
        path = process_dir / name
        if path.is_file():
            return path
    return None


def _review_media(batch_dir: Path, item_dir: Path, artifact_name: str) -> Dict[str, str]:
    path = validated_promoted_artifact_path(item_dir, artifact_name)
    status = "已明确通过"
    if path is None:
        path = _review_candidate_path(item_dir, artifact_name)
        status = "待明确验收"
    if path is None:
        return {"url": "", "status": "尚无候选", "source_path": "", "sha256": ""}
    relative_item = path.relative_to(item_dir).as_posix()
    relative_batch = path.relative_to(batch_dir).as_posix()
    task = read_json(read_compatible_path(item_dir, "任务状态", "任务信息.json"), {})
    return {
        "url": quote(relative_batch),
        "status": status,
        "source_path": relative_item,
        "sha256": _sha256_file(path),
        "version": "V02" if task.get("retry_count") == 1 else "V01",
    }


def _organization_result_has_errors(result: Dict[str, object]) -> bool:
    audit = result.get("output_audit")
    if isinstance(audit, dict) and _audit_result_has_errors(audit):
        return True
    items = result.get("items", [])
    return isinstance(items, list) and any(
        isinstance(item, dict) and _organization_result_has_errors(item) for item in items
    )


def build_review_report(batch_dir: Path, video_ids: Optional[List[str]] = None) -> Path:
    batch_dir = batch_dir.resolve()
    cards = []
    for item_dir in sorted(path for path in batch_dir.iterdir() if path.is_dir() and re.match(r"V\d{3}_", path.name)):
        video_id = item_dir.name.split("_", 1)[0]
        if video_ids is not None and video_id not in video_ids:
            continue
        title_path = validated_promoted_artifact_path(item_dir, "标题.txt") or _review_candidate_path(item_dir, "标题.txt")
        title = title_path.read_text(encoding="utf-8") if title_path is not None else "标题尚无候选"
        task = read_json(read_compatible_path(item_dir, "任务状态", "任务信息.json"), {})
        auto_qa_path = read_compatible_path(item_dir, "验收记录", "自动验收报告.md")
        auto_qa = auto_qa_path.read_text(encoding="utf-8") if auto_qa_path.exists() else "尚无自动验收报告"
        video = _review_media(batch_dir, item_dir, "视频.mp4")
        if not video["url"]:
            continue
        cover = _review_media(batch_dir, item_dir, "封面图.png")
        video_tag = f'<video controls preload="metadata" src="{video["url"]}"></video>' if video["url"] else '<p class="missing">视频尚未下载</p>'
        cover_tag = f'<img src="{cover["url"]}" alt="{video_id} 封面">' if cover["url"] else ""
        video_evidence = html.escape(
            f'视频：{video["status"]}；候选：{video["source_path"] or "无"}；SHA-256：{video["sha256"] or "无"}'
        )
        cards.append(
            f'''<section class="video-card" data-video-id="{html.escape(video_id)}" data-video-source="{html.escape(video["source_path"])}" data-video-sha256="{html.escape(video["sha256"])}" data-video-version="{html.escape(video["version"])}">
  <h2>{html.escape(video_id)}</h2>
  <div class="media">{video_tag}{cover_tag}</div>
  <p>{video_evidence}</p>
  <pre>{html.escape(title)}</pre>
  <p>task_id：{html.escape(str(task.get("task_id") or "未提交"))}</p>
  <details><summary>自动验收摘要</summary><pre>{html.escape(auto_qa)}</pre></details>
  <label><input type="radio" name="{video_id}" value="passed"> 通过</label>
  <label><input type="radio" name="{video_id}" value="failed"> 不通过</label>
  <label>不通过原因<textarea class="reason" rows="3"></textarea></label>
  <label>修改建议<textarea class="suggestion" rows="2"></textarea></label>
</section>'''
        )

    document = f'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>批次验收报告</title><style>
body{{font-family:"Microsoft YaHei",sans-serif;background:#f4f6f8;margin:0;padding:24px;color:#172033}}
main{{max-width:1100px;margin:auto}}.video-card{{background:white;border-radius:16px;padding:20px;margin:18px 0;box-shadow:0 6px 24px #18315318}}
.media{{display:flex;gap:16px;overflow:auto}}video,img{{max-height:480px;max-width:45%;border-radius:12px;background:#111}}
label{{display:block;margin:10px 0}}textarea{{display:block;width:100%;box-sizing:border-box;margin-top:6px}}button{{padding:12px 20px;border:0;border-radius:10px;background:#1467d8;color:white;font-weight:700}}pre{{white-space:pre-wrap}}
</style></head><body><main><h1>批次验收报告</h1>{''.join(cards)}
<button id="complete">完成验收并下载结果</button><p id="error"></p></main><script>
document.getElementById('complete').addEventListener('click',()=>{{
  const items=[]; let error='';
  document.querySelectorAll('.video-card').forEach(card=>{{
    const choice=card.querySelector('input[type=radio]:checked');
    const reason=card.querySelector('.reason').value.trim();
    if(!choice) error='每个视频都必须选择通过或不通过';
    if(choice && choice.value==='failed' && !reason) error='不通过的视频必须填写原因';
    items.push({{video_id:card.dataset.videoId,decision:choice?choice.value:'',reason,suggestion:card.querySelector('.suggestion').value.trim(),artifacts:{{'视频.mp4':{{source_path:card.dataset.videoSource,sha256:card.dataset.videoSha256,version:card.dataset.videoVersion}}}}}});
  }});
  if(error){{document.getElementById('error').textContent=error;return;}}
  const blob=new Blob([JSON.stringify({{completed_at:new Date().toISOString(),items}},null,2)],{{type:'application/json'}});
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='批次验收结果.json';a.click();URL.revokeObjectURL(a.href);
}});
</script></body></html>'''
    output = batch_dir / "批次验收报告.html"
    atomic_write_text(output, document)
    return output


def record_review(batch_dir: Path, result_path: Path, knowledge_dir: Path) -> None:
    result = read_json(result_path)
    items = result.get("items", [])
    if not items:
        raise ValueError("验收结果没有视频项目")
    for decision in items:
        if decision.get("decision") not in {"passed", "failed"}:
            raise ValueError("每个视频都必须选择通过或不通过")
        if decision["decision"] == "failed" and not str(decision.get("reason", "")).strip():
            raise ValueError("不通过的视频必须填写原因")
    atomic_write_json(batch_dir / "批次验收结果.json", result)
    markdown = ["# 批次验收结果", ""]
    confirmation = read_json(batch_dir / "启动确认单.json", {})
    for decision in items:
        item_dir = _find_item(batch_dir, decision["video_id"])
        item_md = (
            f"# 人工验收结果\n\n结果：{decision['decision']}\n\n"
            f"原因：{decision.get('reason', '')}\n\n建议：{decision.get('suggestion', '')}\n"
        )
        atomic_write_text(work_path(item_dir, "验收记录", "人工验收结果.md"), item_md)
        markdown.append(f"- {decision['video_id']}：{decision['decision']}；{decision.get('reason', '')}")
        if decision["decision"] == "failed" and confirmation.get("run_mode") == "learning":
            reason = str(decision["reason"]).strip()
            suggestion = str(decision.get("suggestion", "")).strip()
            node = str(decision.get("node", "video"))
            capture_learning_issue(
                knowledge_dir=knowledge_dir,
                batch_dir=batch_dir,
                video_id=decision["video_id"],
                node=node,
                user_feedback=reason,
                symptom=str(decision.get("symptom") or reason),
                root_cause=str(decision.get("root_cause") or "未知，待 V02 验证"),
                solution=str(decision.get("solution") or suggestion or f"针对用户反馈修正{node}节点"),
                prevention_rule=str(
                    decision.get("prevention_rule")
                    or suggestion
                    or f"进入{node}节点前检查并规避：{reason}"
                ),
                validation_method=str(
                    decision.get("validation_method")
                    or "核对 V02 对应自动检查结果并取得用户明确通过"
                ),
                validation_expected=str(
                    decision.get("validation_expected") or f"V02 不再出现：{reason}"
                ),
                model=decision.get("model"),
                channel=decision.get("channel"),
            )
    atomic_write_text(batch_dir / "批次验收结果.md", "\n".join(markdown) + "\n")


def _parse_points(values: Iterable[str]) -> Tuple[str, ...]:
    points: List[str] = []
    for value in values:
        points.extend(part.strip() for part in value.split("|") if part.strip())
    return tuple(points)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="产品视频技能包便携工作流工具（不直接生成付费内容）")
    subparsers = parser.add_subparsers(dest="command", required=True)

    init = subparsers.add_parser("init", help="创建批次、启动确认单和独立视频目录")
    init.add_argument("--startup-confirmation", type=Path, help="本次用户确认记录；缺失时拒绝初始化")
    init.add_argument("--product-dir", type=Path, required=True)
    init.add_argument("--product-name", required=True)
    init.add_argument("--selling-point", action="append", required=True, help="可重复；也可用 | 分隔")
    init.add_argument("--total", type=int, required=True)
    init.add_argument("--mode", choices=("learning", "auto"), required=True)
    init.add_argument("--resolution", choices=("768P", "2K"), default="768P")
    init.add_argument("--max-budget", required=True)
    init.add_argument("--cover-reference-dir", type=Path, required=True)
    init.add_argument("--knowledge-dir", type=Path, default=Path(__file__).resolve().parents[1] / "data")
    init.add_argument(
        "--image-provider",
        type=_cli_image_provider,
        choices=("codex", "chatgpt_web", "third_party_api"),
        required=True,
        help="用户明确选择的单一生图渠道；无默认值",
    )
    init.add_argument("--image-api-config", type=Path)

    validate = subparsers.add_parser("validate-content", help="校验并保存一条结构化策划内容")
    validate.add_argument("--item-dir", type=Path, required=True)
    validate.add_argument("--content", type=Path, required=True)
    validate.add_argument("--profile", type=Path, required=True)

    review = subparsers.add_parser("build-review", help="生成离线批次验收报告")
    review.add_argument("--batch", type=Path, required=True)

    task = subparsers.add_parser("record-task", help="立即记录 AutoDL task_id")
    task.add_argument("--batch", type=Path, required=True)
    task.add_argument("--video-id", required=True)
    task.add_argument("--task-id", required=True)
    task.add_argument("--request-id")
    task.add_argument("--request-hash")
    task.add_argument("--estimated-cost")

    record = subparsers.add_parser("record-review", help="回写验收结果并形成候选经验")
    record.add_argument("--batch", type=Path, required=True)
    record.add_argument("--result", type=Path, required=True)
    record.add_argument("--knowledge-dir", type=Path, default=Path(__file__).resolve().parents[1] / "data")

    issue = subparsers.add_parser("record-issue", help="记录学习模式用户问题并形成结构化候选经验")
    issue.add_argument("--knowledge-dir", type=Path, required=True)
    issue.add_argument("--batch", type=Path, required=True)
    issue.add_argument("--video-id", required=True)
    issue.add_argument("--node", choices=sorted(LEARNING_NODES), required=True)
    issue.add_argument("--feedback", required=True)
    issue.add_argument("--symptom", required=True)
    issue.add_argument("--root-cause", required=True)
    issue.add_argument("--solution", required=True)
    issue.add_argument("--prevention-rule", required=True)
    issue.add_argument("--validation-method", required=True)
    issue.add_argument("--validation-expected", required=True)
    issue.add_argument("--evidence", type=Path, action="append", default=[])
    issue.add_argument("--model")
    issue.add_argument("--channel")

    learning_validation = subparsers.add_parser(
        "validate-learning", help="回写 V02 验证结果并在通过后自动升级正式规则"
    )
    learning_validation.add_argument("--knowledge-dir", type=Path, required=True)
    learning_validation.add_argument("--batch", type=Path, required=True)
    learning_validation.add_argument("--video-id", required=True)
    learning_validation.add_argument("--issue-id", required=True)
    learning_validation.add_argument(
        "--result", choices=("passed", "failed", "inconclusive"), required=True
    )
    learning_validation.add_argument("--candidate", type=Path)

    node_rules = subparsers.add_parser(
        "prepare-node-rules", help="为当前节点加载正式规避规则并记录命中"
    )
    node_rules.add_argument("--knowledge-dir", type=Path, required=True)
    node_rules.add_argument("--batch", type=Path, required=True)
    node_rules.add_argument("--video-id", required=True)
    node_rules.add_argument("--node", choices=sorted(LEARNING_NODES), required=True)
    node_rules.add_argument("--model")
    node_rules.add_argument("--channel")

    rerun = subparsers.add_parser("start-rerun", help="把失败任务切换为唯一一次 V02 重跑")
    rerun.add_argument("--batch", type=Path, required=True)
    rerun.add_argument("--video-id", required=True)

    organize = subparsers.add_parser("organize", help="安全整理单条任务目录的工作文件")
    organize_target = organize.add_mutually_exclusive_group(required=True)
    organize_target.add_argument("--item-dir", type=Path)
    organize_target.add_argument("--batch", type=Path)
    organize.add_argument("--dry-run", action="store_true")

    output_review = subparsers.add_parser("review-output", help="记录单项产出验收决定并按规则晋升或撤下")
    output_review.add_argument("--item-dir", type=Path, required=True)
    output_review.add_argument("--artifact", choices=sorted(DELIVERABLE_NAMES), required=True)
    output_review.add_argument("--source", type=Path, required=True)
    output_review.add_argument("--decision", choices=sorted(APPROVAL_DECISIONS), required=True)
    output_review.add_argument("--confirmed-by", required=True)
    output_review.add_argument("--feedback", required=True)

    output_audit = subparsers.add_parser("audit-outputs", help="审计并撤下没有明确通过证据的一级产出")
    output_audit_target = output_audit.add_mutually_exclusive_group(required=True)
    output_audit_target.add_argument("--item-dir", type=Path)
    output_audit_target.add_argument("--batch", type=Path)
    output_audit.add_argument("--dry-run", action="store_true")
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "init":
            gate_spec = importlib.util.spec_from_file_location("startup_gate", Path(__file__).with_name("startup_gate.py"))
            gate = importlib.util.module_from_spec(gate_spec)
            gate_spec.loader.exec_module(gate)
            gate.require_confirmation(args.startup_confirmation, {
                "product_dir": args.product_dir, "product_name": args.product_name,
                "selling_points": _parse_points(args.selling_point), "total": args.total,
                "mode": args.mode, "resolution": args.resolution,
                "max_budget": args.max_budget, "cover_reference_dir": args.cover_reference_dir,
                "image_provider": args.image_provider,
            })
            context = initialize_batch(
                product_dir=args.product_dir,
                product_name=args.product_name,
                selling_points=_parse_points(args.selling_point),
                total_videos=args.total,
                run_mode=args.mode,
                resolution=args.resolution,
                max_budget_yuan=args.max_budget,
                cover_reference_dir=args.cover_reference_dir,
                knowledge_dir=args.knowledge_dir,
                image_provider=args.image_provider,
                image_api_config=(
                    json.loads(args.image_api_config.read_text(encoding="utf-8"))
                    if args.image_api_config is not None
                    else None
                ),
            )
            print(context.batch_dir)
        elif args.command == "validate-content":
            save_content_package(args.item_dir, args.content, args.profile)
            print("内容校验通过并已落盘")
        elif args.command == "build-review":
            print(build_review_report(args.batch))
        elif args.command == "record-task":
            record_task(
                args.batch,
                args.video_id,
                args.task_id,
                request_id=args.request_id,
                request_hash=args.request_hash,
                estimated_cost_yuan=args.estimated_cost,
            )
            print("task_id 已记录")
        elif args.command == "record-review":
            record_review(args.batch, args.result, args.knowledge_dir)
            print("验收结果已回写，失败项已进入候选经验")
        elif args.command == "record-issue":
            print(
                capture_learning_issue(
                    knowledge_dir=args.knowledge_dir,
                    batch_dir=args.batch,
                    video_id=args.video_id,
                    node=args.node,
                    user_feedback=args.feedback,
                    symptom=args.symptom,
                    root_cause=args.root_cause,
                    solution=args.solution,
                    prevention_rule=args.prevention_rule,
                    validation_method=args.validation_method,
                    validation_expected=args.validation_expected,
                    evidence_paths=tuple(args.evidence),
                    model=args.model,
                    channel=args.channel,
                ).resolve()
            )
        elif args.command == "validate-learning":
            if args.result == "passed" and args.candidate is None:
                raise ValueError("验证通过必须提供 --candidate")
            result = validate_learning_issue(
                knowledge_dir=args.knowledge_dir,
                batch_dir=args.batch,
                video_id=args.video_id,
                issue_id=args.issue_id,
                result=args.result,
                verified_candidate=args.candidate,
            )
            print(result.resolve() if result is not None else "未升级正式规则")
        elif args.command == "prepare-node-rules":
            print(
                prepare_node_rules(
                    knowledge_dir=args.knowledge_dir,
                    batch_dir=args.batch,
                    video_id=args.video_id,
                    node=args.node,
                    model=args.model,
                    channel=args.channel,
                ).resolve()
            )
        elif args.command == "start-rerun":
            print(start_rerun(args.batch, args.video_id).resolve())
        elif args.command == "organize":
            result = (
                organize_item_dir(args.item_dir, dry_run=args.dry_run)
                if args.item_dir is not None
                else organize_batch_dir(args.batch, dry_run=args.dry_run)
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            if _organization_result_has_errors(result):
                return 2
        elif args.command == "review-output":
            event = record_artifact_decision(
                args.item_dir,
                args.artifact,
                args.source,
                args.decision,
                args.confirmed_by,
                args.feedback,
            )
            if args.decision == "passed":
                result = {"event": event, "promoted": str(promote_approved_artifact(args.item_dir, event))}
            else:
                result = {"event": event, "audit": audit_promoted_outputs(args.item_dir)}
            print(json.dumps(result, ensure_ascii=False, indent=2))
        elif args.command == "audit-outputs":
            result = (
                audit_promoted_outputs(args.item_dir, dry_run=args.dry_run)
                if args.item_dir is not None
                else audit_batch_outputs(args.batch, dry_run=args.dry_run)
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            if _audit_result_has_errors(result):
                return 2
        return 0
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as exc:
        print(f"错误：{exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
