"""Locked prompt contracts for native-4K images and 15-second videos."""

from __future__ import annotations

import math
import re
from typing import Mapping, Sequence


IMAGE_SIZE = (2160, 3840)
IMAGE_ARTIFACTS = {"分镜图.png", "尾帧图.png", "封面图.png"}
FORBIDDEN_PRODUCT_APPEARANCE_TERMS = (
    "踏板",
    "脚踏",
    "车架",
    "轮胎",
    "控制器",
    "扶手",
    "靠背",
)

EXTRA_VOICE_PERMISSION_TERMS = (
    "允许额外人声",
    "允许额外语音",
    "允许旁白",
    "允许画外音",
    "允许第三人声",
    "允许背景音乐",
    "允许BGM",
    "允许哼声",
)

APPEARANCE_DESCRIPTION_TERMS = (
    "黑色",
    "白色",
    "红色",
    "蓝色",
    "灰色",
    "银色",
    "金色",
    "圆形",
    "方形",
    "流线型",
    "弧形",
    "加粗",
    "加宽",
    "加长",
    "加厚",
    "增大",
    "真皮",
    "皮质",
    "金属",
    "塑料",
    "铝合金",
    "碳纤维",
    "改成",
    "变成",
    "换成",
)

PRODUCT_REDESIGN_TERMS = (
    "加装",
    "新增",
    "增加",
    "删减",
    "删除",
    "拆除",
    "替换",
    "改造",
    "重新设计",
    "补画",
)

_COMPONENT_PATTERN = "(?:" + "|".join(
    re.escape(term) for term in FORBIDDEN_PRODUCT_APPEARANCE_TERMS
) + ")"
_APPEARANCE_PATTERN = "(?:" + "|".join(
    re.escape(term) for term in APPEARANCE_DESCRIPTION_TERMS
) + ")"
_REDESIGN_PATTERN = "(?:" + "|".join(
    re.escape(term) for term in PRODUCT_REDESIGN_TERMS
) + ")"
_COMPONENT_SUFFIX_REDESIGN_PATTERN = "(?:" + "|".join(
    re.escape(term) for term in PRODUCT_REDESIGN_TERMS if term != "增加"
) + ")"
_COMPONENT_PREFIX_MODIFIER = re.compile(
    rf"(?:{_APPEARANCE_PATTERN}|{_REDESIGN_PATTERN})\s*(?:的)?\s*{_COMPONENT_PATTERN}"
)
_COMPONENT_SUFFIX_APPEARANCE = re.compile(
    rf"{_COMPONENT_PATTERN}\s*(?:的)?\s*{_APPEARANCE_PATTERN}"
)
_COMPONENT_LINKED_APPEARANCE = re.compile(
    rf"{_COMPONENT_PATTERN}\s*(?:颜色是|采用|使用|做成|制成|上有|带有|具有|是|为)\s*{_APPEARANCE_PATTERN}"
)
_COMPONENT_SUFFIX_REDESIGN = re.compile(
    rf"{_COMPONENT_PATTERN}\s*(?:进行|被)?\s*{_COMPONENT_SUFFIX_REDESIGN_PATTERN}"
)

PRODUCT_REFERENCE_BLOCK = """【产品参考锁定】
上传的产品参考图是唯一产品依据。直接使用参考图中的产品，保持结构、部件、比例、连接关系和相对位置完全不变。
禁止重新设计、补画、删减、替换或推测任何产品部件。不要用文字重新描述产品的颜色、形状、材质或部件外观。"""

NATIVE_4K_BLOCK = """【原生输出参数】
使用渠道支持的原生分辨率生成9:16竖屏图，不强制4K。禁止本地放大、拉伸或裁剪冒充原生输出。"""


def valid_portrait_dimensions(width, height):
    """Allow at most one width pixel of rounding for native 9:16 output."""
    return (type(width) is int and type(height) is int and width > 0 and height > width
            and abs(width * 16 - height * 9) <= 16)

VIDEO_VISUAL_BLOCK = """【固定画面规则】
0–15秒全程一个连续镜头，固定中远景，禁止切镜、跳切或转场。
人物全身和产品整体始终完整位于画面安全区。
分镜图是全程唯一画面基准：在同一张画面上做局部动画，不重新创作画面。
固定机位，背景、构图、景别、光线、人物身份与服装、产品外观和数量全程保持分镜一致；禁止推拉、摇移、环绕、变焦、换景、插入空镜、特写或无关画面。
只允许说话口型、自然微表情和分镜明确指定的产品运动；未指定运动时产品保持原位。运动不得改变产品结构或使主体离开画面。
尾帧仅作为同一画面内动作结束状态，不得引入新场景或新构图；不得根据台词或卖点联想生成其他画面。"""

TAIL_CONTINUITY_BLOCK = """【尾帧画面延续】
以已提供的分镜图为画面基准，保持同一背景、构图、机位、光线、人物身份与服装及产品外观和数量；只表现分镜明确指定动作的结束状态。不得另创场景或改变景别，不额外安排动作。"""

VIDEO_AUDIO_BLOCK = """【固定口播规则】
人物严格交替说话；每句只由指定人物说出。
当前说话者开口时，非当前说话者嘴巴闭合且完全不发声。非当前说话者不得出现口型、气声、附和、笑声或含混发声。
最后一句台词结束后，所有人物闭嘴，不再开口。
只能说逐句台词清单中列出的中文台词；清单之外零人声。禁止旁白、画外音、第三人声、额外人声、哼声、伪语言、乱码语音或任何无法理解的发声。
不得添加任何额外语音；只使用原生中文台词；不得添加背景音乐。"""


def _clean_text(value: str, field: str) -> str:
    if not isinstance(value, str) or not (cleaned := value.strip()):
        raise ValueError(f"{field} 必须是非空文本")
    return cleaned


def _reject_product_appearance(text: str) -> None:
    if has_forbidden_product_appearance(text):
        raise ValueError("产品外观不得推测或描述")


def has_forbidden_product_appearance(text: object) -> bool:
    """Reject concrete component appearance or redesign prose, not actions."""
    if not isinstance(text, str):
        return False
    return bool(
        _COMPONENT_PREFIX_MODIFIER.search(text)
        or _COMPONENT_SUFFIX_APPEARANCE.search(text)
        or _COMPONENT_LINKED_APPEARANCE.search(text)
        or _COMPONENT_SUFFIX_REDESIGN.search(text)
    )


def _has_positive_extra_voice_permission(text: str) -> bool:
    """Treat only an affirmative permission as a conflict with closed audio."""
    negators = ("不", "不要", "不得", "禁止", "不可", "严禁")
    for term in EXTRA_VOICE_PERMISSION_TERMS:
        offset = text.find(term)
        while offset != -1:
            prefix = text[max(0, offset - 2):offset]
            if not any(prefix.endswith(negator) for negator in negators):
                return True
            offset = text.find(term, offset + len(term))
    return False


def _without_contract_blocks(scene: str, blocks: Sequence[str]) -> str:
    """Allow recompilation without copying a previous contract block twice."""
    for block in blocks:
        scene = scene.replace(block, "")
    return scene.strip()


def compile_image_prompt(base_prompt: str, artifact_name: str) -> str:
    """Append the immutable product-reference and native-4K image requirements."""
    if artifact_name not in IMAGE_ARTIFACTS:
        raise ValueError(f"artifact 不受支持：{artifact_name}")
    scene = _without_contract_blocks(
        _clean_text(base_prompt, "base_prompt"),
        (PRODUCT_REFERENCE_BLOCK, NATIVE_4K_BLOCK, TAIL_CONTINUITY_BLOCK),
    )
    _reject_product_appearance(scene)
    if not scene:
        raise ValueError("base_prompt 必须包含场景文本")
    blocks = [scene, PRODUCT_REFERENCE_BLOCK, NATIVE_4K_BLOCK]
    if artifact_name == "尾帧图.png":
        blocks.append(TAIL_CONTINUITY_BLOCK)
    return "\n\n".join(blocks)


def validate_image_request(
    prompt: str, reference_paths: list[str], width: int, height: int
) -> list[str]:
    """Return image request violations without changing the request values."""
    issues: list[str] = []
    if not reference_paths or not all(isinstance(path, str) and path.strip() for path in reference_paths):
        issues.append("image.reference_missing")
    text = prompt if isinstance(prompt, str) else ""
    try:
        _reject_product_appearance(text)
    except ValueError:
        issues.append("image.product_appearance_forbidden")
    if PRODUCT_REFERENCE_BLOCK not in text:
        issues.append("image.reference_lock_missing")
    if NATIVE_4K_BLOCK not in text:
        issues.append("image.native_resolution_missing")
    if (width, height) != (None, None) and not valid_portrait_dimensions(width, height):
        issues.append("image.dimensions_invalid")
    return issues


def _person_profiles(people: list[dict[str, object]]) -> tuple[tuple[str, str], dict[str, str]]:
    if len(people) != 2:
        raise ValueError("视频必须有两名不同人物")
    ids: list[str] = []
    identities: dict[str, str] = {}
    for person in people:
        if not isinstance(person, Mapping):
            raise ValueError("视频必须有两名不同人物")
        identifier = person.get("id")
        if not isinstance(identifier, str) or not identifier.strip():
            raise ValueError("视频必须有两名不同人物")
        identity = person.get("identity")
        if not isinstance(identity, str) or not identity.strip():
            raise ValueError("视频人物必须包含身份映射")
        identifier = identifier.strip()
        ids.append(identifier)
        identities[identifier] = identity.strip()
    if len(set(ids)) != 2:
        raise ValueError("视频必须有两名不同人物")
    return (ids[0], ids[1]), identities


def _validated_segments(
    segments: list[dict[str, object]], person_ids: tuple[str, str]
) -> list[tuple[float, float, str, str]]:
    if not segments:
        raise ValueError("视频必须有时间段")
    prepared: list[tuple[float, float, str, str]] = []
    previous_end: float | None = None
    previous_speaker: str | None = None
    for segment in segments:
        if not isinstance(segment, Mapping):
            raise ValueError("视频时间段格式无效")
        start, end = segment.get("start"), segment.get("end")
        speaker, dialogue = segment.get("speaker_id"), segment.get("dialogue")
        if (
            isinstance(start, bool)
            or isinstance(end, bool)
            or not isinstance(start, (int, float))
            or not isinstance(end, (int, float))
            or not math.isfinite(float(start))
            or not math.isfinite(float(end))
            or start < 0
            or end > 15
            or end <= start
        ):
            raise ValueError("视频时间段必须位于0–15秒且满足 start < end")
        if previous_end is not None and start < previous_end:
            raise ValueError("视频时间段不得重叠且必须按顺序")
        if not isinstance(speaker, str) or speaker not in person_ids:
            raise ValueError("视频时间段说话人无效")
        if previous_speaker == speaker:
            raise ValueError("视频时间段必须严格交替说话")
        cleaned_dialogue = _clean_text(dialogue, "dialogue")
        if any(existing[3] == cleaned_dialogue for existing in prepared):
            raise ValueError("视频台词不得重复")
        prepared.append((float(start), float(end), speaker, cleaned_dialogue))
        previous_end = float(end)
        previous_speaker = speaker
    return prepared


def _format_second(value: float) -> str:
    return str(int(value)) if value.is_integer() else str(value)


def compile_video_prompt(
    base_prompt: str,
    people: list[dict[str, object]],
    segments: list[dict[str, object]],
) -> str:
    """Compile a single-shot, two-person Chinese dialogue video prompt."""
    scene = _without_contract_blocks(
        _clean_text(base_prompt, "base_prompt"),
        (PRODUCT_REFERENCE_BLOCK, VIDEO_VISUAL_BLOCK, VIDEO_AUDIO_BLOCK),
    )
    _reject_product_appearance(scene)
    person_ids, person_identities = _person_profiles(people)
    validated_segments = _validated_segments(segments, person_ids)
    dialogue_lines = [
        f"{_format_second(start)}–{_format_second(end)}秒 speaker_id={speaker}（{person_identities[speaker]}）：{dialogue}"
        for start, end, speaker, dialogue in validated_segments
    ]
    return "\n\n".join((
        scene,
        PRODUCT_REFERENCE_BLOCK,
        VIDEO_VISUAL_BLOCK,
        VIDEO_AUDIO_BLOCK,
        "【逐句台词】\n" + "\n".join(dialogue_lines),
    ))


def validate_video_request(prompt: str, segments: list[dict[str, object]]) -> list[str]:
    """Return stable video contract violations without changing the prompt."""
    text = prompt if isinstance(prompt, str) else ""
    issues: list[str] = []
    if isinstance(prompt, str):
        try:
            _reject_product_appearance(prompt)
        except ValueError:
            issues.append("video.product_appearance_forbidden")
        if _has_positive_extra_voice_permission(prompt):
            issues.append("video.extra_voice_permission_forbidden")
    required_rules = (
        ("产品参考图是唯一产品依据", "video.reference_lock_missing"),
        ("0–15秒", "video.single_shot_missing"),
        ("一个连续镜头", "video.single_shot_missing"),
        ("固定中远景", "video.framing_missing"),
        ("固定机位", "video.framing_missing"),
        ("分镜图是全程唯一画面基准", "video.storyboard_lock_missing"),
        ("只允许说话口型、自然微表情和分镜明确指定的产品运动", "video.motion_scope_missing"),
        ("人物全身和产品整体始终完整位于画面安全区", "video.safe_area_missing"),
        ("严格交替说话", "video.speaker_alternation_missing"),
        ("非当前说话者嘴巴闭合且完全不发声", "video.non_speaker_silence_missing"),
        ("最后一句台词结束后，所有人物闭嘴，不再开口", "video.closed_dialogue_missing"),
        ("不得添加任何额外语音", "video.extra_voice_missing"),
        ("清单之外零人声", "video.extra_voice_missing"),
        ("只使用原生中文台词", "video.native_chinese_missing"),
        ("不得添加背景音乐", "video.bgm_missing"),
    )
    for rule, code in required_rules:
        if rule not in text and code not in issues:
            issues.append(code)
    try:
        dialogues = [
            _clean_text(segment.get("dialogue"), "dialogue")
            for segment in segments
            if isinstance(segment, Mapping)
        ]
        if len(dialogues) != len(segments):
            raise ValueError
    except (TypeError, ValueError):
        issues.append("video.segments_invalid")
        return issues
    if any(text.count(dialogue) != 1 for dialogue in dialogues):
        issues.append("video.dialogue_exactly_once")
    for segment in segments:
        if not isinstance(segment, Mapping):
            continue
        start, end = segment.get("start"), segment.get("end")
        speaker = segment.get("speaker_id")
        if (
            isinstance(start, bool)
            or isinstance(end, bool)
            or not isinstance(start, (int, float))
            or not isinstance(end, (int, float))
            or not math.isfinite(float(start))
            or not math.isfinite(float(end))
            or not isinstance(speaker, str)
        ):
            continue
        binding = (
            f"{_format_second(float(start))}–{_format_second(float(end))}秒 "
            f"speaker_id={speaker}（"
        )
        if binding not in text:
            issues.append("video.speaker_identity_missing")
            break
    return issues
